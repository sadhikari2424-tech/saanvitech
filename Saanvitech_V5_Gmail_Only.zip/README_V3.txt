SAANVITECH V3

This release fixes the previous mailto problem.

Lead form:
- Uses FormSubmit AJAX
- Sends enquiries to s.adhikari2424@gmail.com
- Does not open Google/Gmail
- Keeps visitor on the website
- Shows Sending / Success / Error status

Official FormSubmit documentation confirms AJAX form submissions can be sent without leaving the website.
