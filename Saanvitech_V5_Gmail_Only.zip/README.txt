SAANVITECH V1 — COMPLETE CORPORATE WEBSITE + LEAD GENERATION

Open index.html in a browser to preview the website.

Website files:
- index.html
- styles.css
- script.js

Lead generation:
- Saanvitech_n8n_lead_workflow.json
- SETUP.txt

Before going live:
1. Put your real n8n production webhook URL in script.js.
2. Configure Google Sheets and email credentials in n8n.
3. Replace placeholder email / sheet ID.
4. Add your real WhatsApp number.
5. Upload index.html, styles.css and script.js to hosting.

The website is the complete Version 1 corporate site. The n8n workflow is the backend lead-capture component.
