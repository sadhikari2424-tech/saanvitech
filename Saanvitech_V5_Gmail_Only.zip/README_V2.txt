SAANVITECH V2 — CORPORATE WEBSITE + SIMPLE LEAD GENERATION

Included:
- Responsive corporate website
- Engineering + Water Treatment positioning
- Power BI / Data Analytics services
- AI Automation services
- Expert positioning
- Lead enquiry form
- WhatsApp CTA
- Email enquiry CTA

Lead flow:
Visitor -> Website -> Enquiry -> Your Email / WhatsApp -> Consultation

No n8n required.

Before publishing:
Edit script.js and set:
SAANVITECH_EMAIL
WHATSAPP_NUMBER

Next upgrade options:
1. Hosted form backend + Google Sheets lead database
2. CRM integration
3. AI lead qualification
4. Automated email/WhatsApp follow-up
5. n8n automation when you are ready
